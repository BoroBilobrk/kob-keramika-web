KOB-Keramika PWA paket

Datoteke uključene u ZIP:
- manifest.webmanifest
- service-worker.js
- .well-known/assetlinks.json
- README.txt

Što sada trebaš:
1) Prenesi sve ove datoteke u root GitHub repozitorija:
   https://github.com/borobilobrk/kob-keramika-web.

2) U index.html dodaj ovu liniju u <head>:
   <link rel="manifest" href="manifest.webmanifest">

3) I pred kraj <body> dodaj:
   <script>
   if ("serviceWorker" in navigator) {
       navigator.serviceWorker.register("service-worker.js");
   }
   </script>

4) Nakon commita, otvori:
   https://www.pwabuilder.com
   i generiraj APK.

Ako želiš, mogu ti direktno generirati index.html s potpuno integriranim kodom.
